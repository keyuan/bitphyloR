### =========================================================================
### The as.data.frame() generic
### -------------------------------------------------------------------------
###
### base::as.data.frame is an S3 generic.

setGeneric("as.data.frame", signature="x")

